#!/bin/sh
./SRBMiner-MULTI --disable-cpu --algorithm pyrinhash --pool sg.pyrin.herominers.com:1177 --wallet pyrin:qpk6v6sdv97yu2pg2gcfcsx59t59ssuhy9jzkz263kt230dxg22ty9nqmv7zd --password gojes
pause
